<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('m_member');
		$this->load->model('m_admin');
	}
	public function index() { // 1301164259
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$result = $this->m_member->is_login($username, $password)->row_array();
		$name = $this->m_member->is_login($username, $password)->result_array()[0]['name'];
		if ($result > 0) {
			$this->session->set_userdata('name', $name);
			$this->session->set_userdata('username', $username);
			redirect('page/home');
		} else {
			$this->session->set_flashdata('message', 'Username atau password salah');
			redirect('page/signin');
		}
	}
	public function admin() { // 1301164259
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$result = $this->m_admin->is_login($username, $password)->row_array();
		if ($result > 0) {
			$this->session->set_userdata('username_admin', $username);
			redirect('page/admin');
		} else {
			$this->session->set_flashdata('message', 'Username atau password salah');
			redirect('page/signin_admin');
		}
	}	
}