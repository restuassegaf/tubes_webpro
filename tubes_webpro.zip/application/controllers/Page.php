<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('m_member');
		$this->load->model('m_product');
		$this->load->model('m_selling');
	}
	public function index() { // 1301164162
		redirect('page/home');
	}
	public function home() { // 1301164162
		$data["title"] = "Home";
		$data["product"] = $this->m_product->get_product();
		$data["product_buah"] = $this->m_product->get_product_by_category("buah");
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
 		$this->load->view('v_home', $data);
	}
	public function about() { // 1301164162
		$data["title"] = "Tentang Kami";
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
		$this->load->view('v_about', $data);
	}
	public function signup() { // 1301164162
		$data["title"] = "Sign Up";
		$data["member"] = $this->m_member->get_member();
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
		$this->load->view('v_signup', $data);
	}
	public function signin() { // 1301164162
		$data["title"] = "Sign In";
		$this->load->view('v_signin', $data);
	}
	public function signin_admin() { // 1301164162
		$data["title"] = "Sign In Admin";
		$this->load->view('v_signin_admin', $data);
	}
	public function admin() { // 1301164162
		$this->check_login_admin();
		$data["title"] = "Halaman Admin";
		$data["product"] = $this->m_product->get_product();
		$this->load->view('v_admin_page', $data);	
	}
	public function add_product() { // 1301164162
		$this->check_login_admin();
		$data["title"] = "Tambah Produk";
		$this->load->view('v_add_product', $data);
	}
	public function check_login_admin() { // 1301164162
		if (!$this->session->has_userdata('username_admin')) {
			$this->session->set_flashdata('message', 'Anda harus login terlebih dahulu!');
			redirect('page/signin_admin');
		}
	}
	public function edit_product($id) { // 1301164162
		$this->check_login_admin();
		$data["title"] = "Edit Produk";
		$data["product"] = $this->m_product->get_product_by_id($id);
		$this->load->view('v_edit_product', $data);
	}
	public function detail_product($slug) { // 1301164162
		$data["title"] = "Detail Produk";
		$data["product"] = $this->m_product->get_product_by_slug($slug);
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
		$id = $data["product"]["id"];
		$data["review"] = $this->m_product->get_review($id);
		$this->load->view('v_detail_product', $data);
	}
	public function list_member() { // 1301164162
		$this->check_login_admin();
		$data["title"] = "List Member";
		$data["member"] = $this->m_member->get_member();
		$this->load->view('v_list_member', $data);
	}
	public function category($category) { // 1301164162
		$data["title"] = "Kategori ".$category;
		$data["product"] = $this->m_product->get_product_by_category($category);
		$data["category"] = $category;
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
		$this->load->view('v_category', $data);
	}
	public function cart() { // 1301164162
		$data["title"] = "Keranjang Belanja";
		$username = $this->session->userdata('username');
		$data["item"] = $this->m_product->get_cart($username);
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
			$this->load->view('v_cart', $data);
		} else {
			$this->session->set_flashdata("message", "Anda harus login dulu!");
			redirect('page/signin');
		}		
	}
	public function selling() { // 1301164162
		$data["title"] = "Data Penjualan";
		$data["selling"] = $this->m_selling->get_selling();
		$this->load->view("v_list_selling", $data);
	}
	public function search() { // 1301164162
		$data["title"] = "Pencarian";
		$search = $this->input->post("search");
		$data["search"] = $this->input->post("search");
		$data["product"] = $this->m_product->get_product_by_search($search);
		if ($this->session->userdata('username')) {
			$username = $this->session->userdata('username');
			$data["cart_quantity"] = $this->m_product->get_cart($username)->num_rows();
		}
		$this->load->view("v_search", $data);
	}
}