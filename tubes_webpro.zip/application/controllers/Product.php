<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('m_product');
	}
	public function add() { // 1301164222
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']	= 5000;

        $this->upload->initialize($config);

        if ($this->upload->do_upload('image')) {
        	$img = $this->upload->data();

        	$name = $this->input->post('name');
			$description = $this->input->post('description');
			$category = $this->input->post('category');
			$price = $this->input->post('price');
			$stock = $this->input->post('stock');
			$image = $img['file_name'];

	        $trim = trim($name);
	        $slug = strtolower(str_replace(" ", "-", $trim));

	        $this->m_product->add_product($name, $description, $category, $price, $stock, $image, $slug);
	        $this->session->set_flashdata('success', 'Produk berhasil ditambahkan!');
	        redirect('page/add_product');
        } else {
        	$this->session->set_flashdata('failed', $this->upload->display_errors());
			redirect('page/add_product');
    	}
	}
	public function delete($id) { // 1301164222
		$this->m_product->delete_product($id);
		redirect('page/admin');
	}
	public function edit() { // 1301164222
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']	= 5000;

        $this->upload->initialize($config);

        if ($this->upload->do_upload('image')) {
        	$img = $this->upload->data();

        	$id = $this->input->post('id');
        	$name = $this->input->post('name');
			$description = $this->input->post('description');
			$category = $this->input->post('category');
			$price = $this->input->post('price');
			$stock = $this->input->post('stock');
			$image = $img['file_name'];

	        $trim = trim($name);
	        $slug = strtolower(str_replace(" ", "-", $trim));

	        $this->m_product->edit_product($id, $name, $description, $category, $price, $stock, $image, $slug);
	        $this->session->set_flashdata('success', 'Produk berhasil diupdate!');
	        redirect('page/edit_product/'.$id);
        } else {
        	$this->session->set_flashdata('failed', $this->upload->display_errors());
			redirect('page/edit_product/'.$id);
    	}
	}
	public function add_to_cart() { // 1301164222
		if (!$this->session->userdata('username')) {
			$this->session->set_flashdata("message", "Anda harus login dulu!");
			redirect('page/signin');
		} else {
			$username = $this->session->userdata('username');
			$id = $this->input->post('id');
			$stock = $this->m_product->get_product_by_id($id)["stock"];
			$quantity = $this->input->post('quantity');
			$totalpriceperitem = $this->input->post('price') * $quantity;
			if ($quantity > $stock) {
				$this->session->set_flashdata('message', 'Stock yang tersedia tidak mencukupi! Stock tersisa: '.$stock);
				redirect('page/home');
			} else {
				$this->m_product->add_to_cart($quantity, $id, $username, $totalpriceperitem);
				$this->m_product->decrement_stock($id, $quantity);
				$this->session->set_flashdata('message', 'Barang berhasil ditambahkan ke dalam keranjang!');
				redirect('page/home');
			}			
		}		
	}
	public function delete_item_in_cart($item_id, $quantity, $id) { // 1301164222
		$username = $this->session->userdata("username");
		$result = $this->m_product->check_cart_item($username, $item_id)->row_array();
		if ($result > 0) {
			$this->m_product->increment_stock($id, $quantity);
			$this->m_product->delete_item_in_cart($item_id);
			redirect('page/cart');
		} else {
			$this->session->set_flashdata("message", "Anda tidak mempunyai akses!");
			redirect("page/home");
		}
	}
	public function add_selling() { // 1301164222
		$username = $this->session->userdata("username");
		$totalprice = $this->input->post("totalprice");
		$this->m_product->add_selling($username, $totalprice);
		$selling_id = $this->m_product->get_selling_id($username, $totalprice)["selling_id"];
		$this->m_product->edit_item_selling_id($selling_id, $username);
		$this->session->set_flashdata("message", "Pembelian berhasil! silahkan transfer sebesar <strong>Rp. ".$totalprice."</strong> ke rekening berikut: BCA <strong>0481480031</strong>");
		redirect("page/home");
	}
	public function add_review() { // 1301164222
		$id = $this->input->post('id');
		$review = $this->input->post('review');
		$username = $this->session->userdata("username");
		if (!$this->session->userdata("username")) {
			$username = "anonymous";
		}
		$star = $this->input->post('star');
		$slug = $this->input->post('slug');
		$this->m_product->add_review($id, $review, $username, $star);
		redirect("page/detail_product/".$slug);
	}
}