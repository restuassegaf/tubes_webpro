<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('m_member');
	}
	public function index() { // 1301164198
		$username = $this->input->post('username');
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$age = $this->input->post('age');
		$phone = $this->input->post('phone');
		$this->m_member->add_member($name, $username, $password, $email, $age, $phone);
		$this->session->set_userdata('name', $name);
		$this->session->set_userdata('username', $username);
		redirect('page/home');
	}
}