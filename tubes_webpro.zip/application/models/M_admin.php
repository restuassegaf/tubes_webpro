<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model {
	public function is_login($username, $password) { // 1301164222
		$this->db->where("username", $username);
		$this->db->where("password", $password);
		return $this->db->get("admin");
	}
}