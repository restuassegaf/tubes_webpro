<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_member extends CI_Model {
	public function is_login($username, $password) { // 1301164222
		$this->db->where("username", $username);
		$this->db->where("password", $password);
		return $this->db->get("member");
	}
	public function get_member() { // 1301164222
		return $this->db->get("member");
	}
	public function add_member($name, $username, $password, $email, $age, $phone) { // 1301164222
		$data = array(
			"name" => $name,
			"username" => $username,
			"password" => $password,
			"email" => $email,
			"age" => $age,
			"phone" => $phone
		);
		$this->db->insert("member", $data);
	}
}