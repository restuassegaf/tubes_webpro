<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_selling extends CI_Model {
	public function get_selling() { // 1301164222
		return $this->db->get("selling");
	}
}