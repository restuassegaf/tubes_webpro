<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet"> 
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<div class="top-nav container">
			<ul>
			  	<li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span>&nbsp;&nbsp;Home</a></li>
			  	<li><a class="active2" href="<?php echo base_url() ?>page/about"><span class="fa fa-address-card"></span>&nbsp;&nbsp;About Us</a></li>
			  	<li><a href="<?php echo base_url() ?>page/admin"><span class="fa fa-user-secret"></span>&nbsp;&nbsp;Admin</a></li>
			  	<?php if (!$this->session->has_userdata('name')) { ?>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signin"><span class="fa fa-sign-in-alt"></span>&nbsp;&nbsp;Sign In</a></li>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signup"><span class="fa fa-user-plus"></span>&nbsp;&nbsp;Sign Up</a></li>
				<?php } else { ?>				
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>logout"><span class="fa fa-sign-out-alt"></span>&nbsp;&nbsp;Sign Out</a></li>
					<li class="res" style="float:right">
						<a href="<?php echo base_url() ?>page/cart">
							<span class="fa fa-shopping-cart"></span>&nbsp;&nbsp;Cart
							<?php if (isset($cart_quantity)) { ?>
							&nbsp;&nbsp;<span class="badge badge-danger"><?php echo $cart_quantity ?></span>
							<?php } ?>
						</a>
					</li>
					<li class="res" style="float:right; margin:10px 30px 0px 0px;"><span style="color: white;">Halo, <?php echo $this->session->userdata('name') ?>&nbsp;&nbsp;<span class="fa fa-smile"></span></span></li>
				<?php }	?>
			</ul>
		</div>
	</nav>
	<div class="container">
		<div class="row header">
			<div class="col">
				<img style="width: 480px;" src="<?php echo base_url() ?>img/logo/logo.png">
			</div>
			<div class="col">
				<!-- Search -->
				<form method="post" action="<?php echo base_url()?>page/search">
					<div class="input-group mb-3" style="margin-top: 60px;">
					  	<input name="search" type="text" class="form-control" placeholder="Search here...">
					  	<div class="input-group-append">
					    	<input type="submit" class="btn btn-outline-secondary" type="button" value="Search">
					  	</div>
					</div>
				</form>				
				<!-- End of Search -->
			</div>
		</div>
	</div>

	<div class="main container">
		<h2><?php echo $title ?></h2><br>
		<p style="padding: 0px 20px;">Green House menyediakan layanan jual beli produk pertanian dan perkebunan. Produk yang dijual di Green House diambil langsung dari pertanian terbaik yang ada di daerah Bandung dan sekitarnya yang kualitasnya tidak perlu diragukan lagi. Green House dikelola oleh 4 admin yang sangat professional, yaitu Aditya, Hafiz, Raihan, dan Restu.</p><br>
		<div class="row">
			<div class="col-3">
				<center>
					<img style="width: 200px;" class="rounded-circle" src="<?php echo base_url() ?>img/about/aditya.jpg"><br><br>
					<span>
						ADITYA EKA BAGASKARA<br>
						IF-40-11<br>
						1301164222
					</span>
				</center>
			</div>
			<div class="col-3">
				<center>
					<img style="width: 200px;" class="rounded-circle" src="<?php echo base_url() ?>img/about/hafiz.jpg"><br><br>
					<span>
						MUHAMMAD HAFIZ ZAMRUDIN<br>
						IF-40-11<br>
						1301164162
					</span>
				</center>
			</div>
			<div class="col-3">
				<center>
					<img style="width: 200px;" class="rounded-circle" src="<?php echo base_url() ?>img/about/raihan.jpg"><br><br>
					<span>
						M. RAIHAN RAFIIFUL ALLAAM<br>
						IF-40-11<br>
						1301164259
					</span>
				</center>
			</div>
			<div class="col-3">
				<center>
					<img style="width: 200px;" class="rounded-circle" src="<?php echo base_url() ?>img/about/restu.jpg"><br><br>
					<span>
						MUHAMMAD RESTU ASSEGAF<br>
						IF-40-11<br>
						1301164198
					</span>
				</center>
			</div>
		</div>
	</div>

	<div class="main-2 container">
		<div class="row" style="border-bottom: 1px solid #eee; margin-bottom: 10px;">
			<div class="col-9">
				<h4>About Us</h4>
				<img style="float: left; width: 100px; margin: 8px 20px 0px 0px;" src="<?php echo base_url() ?>img/logo/logo2.png">
				<p>Green House menyediakan layanan jual beli produk pertanian dan perkebunan. Produk yang dijual di Green House diambil langsung dari pertanian terbaik yang ada di daerah Bandung dan sekitarnya yang kualitasnya tidak perlu diragukan lagi. Green House dikelola oleh 4 admin yang sangat professional, yaitu Aditya, Hafiz, Raihan, dan Restu.</p>
			</div>
			<div class="col-3">
				<h4>Customer Service</h4>
				<ul>
					<li><a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLScchYk9dq9CBoBy21_uwqhx5vOhKq-As8MAmQxslNMoDrof3w/viewform">Kritik dan Saran</a></li>
					<li><a href="<?php echo base_url()?>page/about">Tentang Kami</a></li>
					<li><a href="<?php echo base_url()?>page/signup">Sign Up</a></li>
					<li><a href="<?php echo base_url()?>page/signin">Sign In</a></li>
				</ul>
			</div>
		</div>
		<div class="row" style="margin-top: 20px;">
			<div class="col">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/facebook.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/twitter.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/instagram.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/youtube.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/googleplus.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/pinterest.png">
			</div>
			<div class="col">
				<div class="input-group mb-3" style="margin-top: 12px;">
				  	<input type="text" class="form-control" placeholder="Enter your email address.." aria-label="Recipient's username" aria-describedby="basic-addon2">
				  	<div class="input-group-append">
				    	<button class="btn btn-outline-secondary" type="button">Subscribe</button>
				  	</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer">
		<div class="mx-auto d-table">
			<span style="font-size: 11px;">
				Copyright 2018 - All Right reserved - Made with&nbsp;&nbsp;<span class="fa fa-heart" style="color:white;"></span>
			</span>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
</body>
</html>