<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet">
</head>
<body>
	<div class="container">
		<div class="row">
			<?php include "v_admin_menu.php" ?>
			<div class="col add-product">
				<h3><?php echo $title ?></h3>
				<?php if ($this->session->flashdata('failed')) { ?>
					<div class="alert alert-danger" role="alert">
						<?php echo $this->session->flashdata('failed') ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('success')) { ?>
					<div class="alert alert-success" role="alert">
						<span class="fa fa-check"></span>&nbsp;&nbsp;<?php echo $this->session->flashdata('success') ?>
					</div>
				<?php } ?>
				<?php echo form_open_multipart('product/add');?>
					<div class="form-group">
						<label>Nama Product</label>
						<input name="name" type="text" class="form-control" placeholder="Pisang">
					</div>
					<div class="form-group">
						<label>Deskripsi</label>
						<textarea name="description" class="form-control"></textarea>
					</div>
					<div class="form-group">
						<label>Kategori</label>
						<select name="category" class="form-control">
							<option value="sayuran">Sayuran</option>
							<option value="buah">Buah Segar</option>
							<option value="cabe">Cabe</option>
							<option value="gula">Gula</option>
							<option value="beras">Beras</option>
							<option value="bawang">Bawang</option>
							<option value="lainnya">Lainnya</option>
						</select>
					</div>
					<div class="form-group">
						<label>Harga</label>
						<div class="input-group mb-2">
							<div class="input-group-prepend">
								<div class="input-group-text">Rp</div>
							</div>
							<input name="price" type="number" class="form-control" placeholder="100000">
						</div>
					</div>
					<div class="form-group">
						<label>Stock</label>
						<input name="stock" type="number" class="form-control" placeholder="100">
					</div>
					<div class="form-group">
						<label>Pilih Gambar</label>
						<input name="image" type="file" class="form-control-file">
					</div>
					<input type="submit" class="btn btn-primary" style="width: 100%; margin-top:20px;" value="Tambah Produk">
				</form>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
</body>
</html>