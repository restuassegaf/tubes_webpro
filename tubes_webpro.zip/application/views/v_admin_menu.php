<div class="col-3 admin-menu">
	<h3>Admin Menu</h3>
	<ul>
		<li><a href="<?php echo base_url() ?>page/add_product">Tambah Produk</a></li>
		<li><a href="<?php echo base_url() ?>page/admin">Lihat Produk</a></li>
		<li><a href="<?php echo base_url() ?>page/selling">Lihat Penjualan</a></li>
		<li><a href="<?php echo base_url() ?>page/list_member">Lihat Member</a></li>
		<li><a href="<?php echo base_url() ?>">Lihat Website</a></li>
		<li><a href="<?php echo base_url() ?>logout">Logout</a></li>
	</ul>
</div>