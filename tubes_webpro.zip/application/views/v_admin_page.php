<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/datatables.min.css"/>
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet">
</head>
<body>
	<div class="container">
		<div class="row">
			<?php include "v_admin_menu.php" ?>
			<div class="col product-list">
				<h3>Data Produk</h3>
				<table id="table" class="table" style="width:100%;">
					<thead>
						<tr>
							<th>Gambar</th>
				     		<th>Nama</th>
							<th>Harga</th>
							<th>Kategori</th>
							<th>Stok</th>
							<th>Tanggal</th>
				         	<th>Aksi</th>
				        </tr>
					</thead>
			     	<tbody>
				     	<?php foreach($product->result_array() as $product_arr) {?>
				     		<tr>
				     			<td>
				     				<img style="width: 100px;" src="<?php echo base_url() ?>uploads/<?php echo $product_arr["image"]?>">
				     			</td>
				     			<td style="vertical-align : middle;"><a href="<?php echo base_url() ?>page/detail_product/<?php echo $product_arr['slug']?>"><?php echo $product_arr["name"]?></a></td>
				     			<td style="vertical-align : middle;">Rp. <?php echo $product_arr["price"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $product_arr["category"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $product_arr["stock"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $product_arr["date"]?></td>
				     			<td style="vertical-align : middle;">
				     				<a style="margin-bottom:10px; width: 100%;" href="<?php echo base_url()?>page/edit_product/<?php echo $product_arr["id"]?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a><br>
				     				<a onclick="return confirm('Yakin ingin menghapus produk ini?');" style="width: 100%;" href="<?php echo base_url()?>product/delete/<?php echo $product_arr["id"]?>" class="btn btn-danger btn-sm"><span class="fa fa-trash-alt"></span></a>
				     			</td>
				     		</tr>
				     	<?php } ?>
			     	</tbody>
			    </table>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/datatables.min.js"></script>
	<script type="text/javascript">
	$(document).ready( function () {
	    $('#table').DataTable();
	});
	</script>
</body>
</html>