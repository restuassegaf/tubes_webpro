<!DOCTYPE html>
<html>
<head>
	<title><?php echo $product["name"] ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet"> 
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<!-- Navigasi Atas -->
		<div class="top-nav container">
			<ul>
			  	<li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span>&nbsp;&nbsp;Home</a></li>
			  	<li><a href="<?php echo base_url() ?>page/about"><span class="fa fa-address-card"></span>&nbsp;&nbsp;About Us</a></li>
			  	<li><a href="<?php echo base_url() ?>page/admin"><span class="fa fa-user-secret"></span>&nbsp;&nbsp;Admin</a></li>
			  	<?php if (!$this->session->has_userdata('name')) { ?>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signin"><span class="fa fa-sign-in-alt"></span>&nbsp;&nbsp;Sign In</a></li>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signup"><span class="fa fa-user-plus"></span>&nbsp;&nbsp;Sign Up</a></li>
				<?php } else { ?>				
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>logout"><span class="fa fa-sign-out-alt"></span>&nbsp;&nbsp;Sign Out</a></li>
					<li class="res" style="float:right">
						<a href="<?php echo base_url() ?>page/cart">
							<span class="fa fa-shopping-cart"></span>&nbsp;&nbsp;Cart
							<?php if (isset($cart_quantity)) { ?>
							&nbsp;&nbsp;<span class="badge badge-danger"><?php echo $cart_quantity ?></span>
							<?php } ?>
						</a>
					</li>
					<li class="res" style="float:right; margin:10px 30px 0px 0px;"><span style="color: white;">Halo, <?php echo $this->session->userdata('name') ?>&nbsp;&nbsp;<span class="fa fa-smile"></span></span></li>
				<?php }	?>
			</ul>
		</div>
		<!-- End of Navigasi Atas -->
	</nav>

	<div class="container">
		<div class="row header">
			<!-- Logo -->
			<div class="col">
				<img class="mx-auto d-block" style="width: 700px;" src="<?php echo base_url() ?>img/logo/logo.png">
			</div>
			<!-- End of Logo -->
		</div>
	</div>

	<div class="main container" style="padding: 20px; width: 800px; margin-bottom: 80px;">
		<div class="detail-product">
			<div class="row">
				<div class="col-4">
					<img style="width: 233px;" src="<?php echo base_url() ?>uploads/<?php echo $product['image'] ?>">
				</div>
				<div class="col">
					<div class="name">
						<h3><?php echo $product["name"] ?></h3>
					</div>
					<div class="price">
						<h3>Rp. <?php echo $product["price"] ?></h3>
					</div>
					<div class="description">
						<?php echo $product["description"] ?>
					</div>
				</div>
			</div>
			<div class="row" style="margin-top: 20px;">
				<div class="col">
					<form action="<?php echo base_url() ?>product/add_to_cart" method="post">
						<div class="form-group d-none">
							<input name="id" readonly type="text" class="form-control" value="<?php echo $product['id']?>">
						</div>
						<div class="form-group d-none">
							<input name="price" readonly type="text" class="form-control" value="<?php echo $product['price']?>">
						</div>
						<div class="form-group">
							<input name="quantity" type="number" class="form-control" placeholder="Jumlah" min="1" required>
						</div>
						<input style="width: 100%;" class="btn btn-primary" type="submit" value="Tambah Keranjang">
					</form>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<h3 style="margin-top: 30px; margin-bottom: 20px;">Ulasan</h3>
					<?php foreach ($review->result_array() as $review_arr) { ?>
						<div class="user-review">
							<h5><?php echo $review_arr["username"] ?></h5>
							<div class="row">
								<div class="col-2">
									<img style="width: 100px;" src="<?php echo base_url() ?>img/profile.png">
								</div>
								<div class="col" style="margin-left: -10px;">
									<p><?php echo $review_arr["review"] ?></p>
									<?php for ($i = 1; $i <= $review_arr["star"]; $i++) { ?>
										<span class="fa fa-star"></span>
									<?php } ?>
								</div>
							</div>
						</div>
					<?php } ?>
					<form method="post" action="<?php echo base_url()?>product/add_review">
						<div class="form-group d-none">
							<input name="id" readonly type="text" class="form-control" value="<?php echo $product['id']?>">
						</div>
						<div class="form-group d-none">
							<input name="slug" readonly type="text" class="form-control" value="<?php echo $product['slug']?>">
						</div>
						<div class="form-group" style="margin-top: 15px;">
							<label>Tulis ulasan anda</label>
							<textarea name="review" class="form-control" required></textarea>
						</div>						
						<div class="form-group">
							<label>Bagaimana kualitas produk ini? skala 1-5</label>
							<input name="star" type="number" class="form-control" min="1" max="5" required>
						</div>
						<input class="btn btn-primary" type="submit" value="Kirim Ulasan">
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<div class="footer fixed-bottom">
		<div class="mx-auto d-table">
			<span style="font-size: 11px;">
				Copyright 2018 - All Right reserved - Made with&nbsp;&nbsp;<span class="fa fa-heart" style="color:white;"></span>
			</span>
		</div>
	</div>
	<!-- End of Footer -->

	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
</body>
</html>