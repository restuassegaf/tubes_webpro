<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/datatables.min.css"/>
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet">
</head>
<body>
	<div class="container">
		<div class="row">
			<?php include "v_admin_menu.php" ?>
			<div class="col product-list">
				<h3>Data Member</h3>
				<table id="table" class="table" style="width:100%;">
					<thead>
						<tr>
							<th>Nama</th>
				     		<th>Email</th>
							<th>Username</th>
							<th>Umur</th>
							<th>Nomor Telepon</th>
				        </tr>
					</thead>
			     	<tbody>
				     	<?php foreach($member->result_array() as $member_arr) {?>
				     		<tr>
				     			<td style="vertical-align : middle;"><?php echo $member_arr["name"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $member_arr["email"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $member_arr["username"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $member_arr["age"]?></td>
				     			<td style="vertical-align : middle;"><?php echo $member_arr["phone"]?></td>
				     		</tr>
				     	<?php } ?>
			     	</tbody>
			    </table>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/datatables.min.js"></script>
	<script type="text/javascript">
	$(document).ready( function () {
	    $('#table').DataTable();
	});
	</script>
</body>
</html>