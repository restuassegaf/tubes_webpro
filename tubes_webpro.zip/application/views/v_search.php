<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/owl.theme.default.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet"> 
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<!-- Navigasi Atas -->
		<div class="top-nav container">
			<ul>
			  	<li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span>&nbsp;&nbsp;Home</a></li>
			  	<li><a href="<?php echo base_url() ?>page/about"><span class="fa fa-address-card"></span>&nbsp;&nbsp;About Us</a></li>
			  	<li><a href="<?php echo base_url() ?>page/admin"><span class="fa fa-user-secret"></span>&nbsp;&nbsp;Admin</a></li>
			  	<?php if (!$this->session->has_userdata('name')) { ?>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signin"><span class="fa fa-sign-in-alt"></span>&nbsp;&nbsp;Sign In</a></li>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signup"><span class="fa fa-user-plus"></span>&nbsp;&nbsp;Sign Up</a></li>
				<?php } else { ?>				
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>logout"><span class="fa fa-sign-out-alt"></span>&nbsp;&nbsp;Sign Out</a></li>
					<li class="res" style="float:right">
						<a href="<?php echo base_url() ?>page/cart">
							<span class="fa fa-shopping-cart"></span>&nbsp;&nbsp;Cart
							<?php if (isset($cart_quantity)) { ?>
							&nbsp;&nbsp;<span class="badge badge-danger"><?php echo $cart_quantity ?></span>
							<?php } ?>
						</a>
					</li>
					<li class="res" style="float:right; margin:10px 30px 0px 0px;"><span style="color: white;">Halo, <?php echo $this->session->userdata('name') ?>&nbsp;&nbsp;<span class="fa fa-smile"></span></span></li>
				<?php }	?>
			</ul>
		</div>
		<!-- End of Navigasi Atas -->
	</nav>
	<div class="container">
		<div class="row header">
			<!-- Logo -->
			<div class="col">
				<img style="width: 480px;" src="<?php echo base_url() ?>img/logo/logo.png">
			</div>
			<!-- End of Logo -->
			<div class="col">
				<!-- Search -->
				<form method="post" action="<?php echo base_url()?>page/search">
					<div class="input-group mb-3" style="margin-top: 60px;">
					  	<input name="search" type="text" class="form-control" placeholder="Search here...">
					  	<div class="input-group-append">
					    	<input type="submit" class="btn btn-outline-secondary" type="button" value="Search">
					  	</div>
					</div>
				</form>				
				<!-- End of Search -->
			</div>
		</div>
	</div>

	<div class="main container">
		<div class="row">
			<!-- Kategori -->
			<div class="col-2 vertical-nav">
				<ul>
					<li><a href="<?php echo base_url() ?>page/category/cabe">Cabe</a></li>
					<li><a href="<?php echo base_url() ?>page/category/buah">Buah Segar</a></li>
					<li><a href="<?php echo base_url() ?>page/category/gula">Gula</a></li>
					<li><a href="<?php echo base_url() ?>page/category/sayuran">Sayuran</a></li>
					<li><a href="<?php echo base_url() ?>page/category/beras">Beras</a></li>
					<li><a href="<?php echo base_url() ?>page/category/bawang">Bawang</a></li>				
					<li><a href="<?php echo base_url() ?>page/category/lainnya">Lainnya</a></li>
				</ul>
			</div>
			<!-- End of Kategori -->
			<div class="col-10">
				<!-- Bootstrap Carousel -->
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
				  	<ol class="carousel-indicators">
				    	<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
				    	<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
				    	<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
				  	</ol>
				  	<div class="carousel-inner">
				    	<div class="carousel-item active">
				      		<img class="d-block w-100" src="<?php echo base_url() ?>img/product/slider-mangga.jpg" alt="First slide">
				    	</div>
				    	<div class="carousel-item">
				      		<img class="d-block w-100" src="<?php echo base_url() ?>img/product/slider-cabe.jpg" alt="Second slide">
				    	</div>
				    	<div class="carousel-item">
				      		<img class="d-block w-100" src="<?php echo base_url() ?>img/product/slider-jeruk.jpg" alt="Third slide">
				    	</div>
				  	</div>
				  	<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				    	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Previous</span>
				  	</a>
				  	<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				    	<span class="carousel-control-next-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Next</span>
				  	</a>
				</div>
				<!-- End of Bootstrap Carousel -->
			</div>
		</div>

		<!-- Owl Carousel -->
		<div class="product">
			<h4 style="border-bottom: 1px solid #eee; margin-bottom:15px; padding-bottom: 10px;">Pencarian <?php echo $search ?></h4>
			<div class="owl-carousel owl-theme">
				<?php foreach ($product->result_array() as $product_arr) { ?>
				    <div class="item">
				    	<a href="<?php echo base_url() ?>/page/detail_product/<?php echo $product_arr['slug']?>">
				    		<img src="<?php echo base_url() ?>uploads/<?php echo $product_arr['image']?>">
				    	</a>
				    	<center>
				    		<a href="<?php echo base_url() ?>/page/detail_product/<?php echo $product_arr['slug']?>"><?php echo $product_arr["name"] ?></a><br>
				    		<a href="<?php echo base_url() ?>/page/detail_product/<?php echo $product_arr['slug']?>">Rp. <?php echo $product_arr["price"] ?></a><br>
				    		<a style="margin-top:5px; width: 100%;" href="<?php echo base_url() ?>/page/detail_product/<?php echo $product_arr['slug']?>" class="btn btn-primary"><span class="fa fa-cart-plus"></span>&nbsp;&nbsp;Beli</a>
				    	</center>
				    </div>
			    <?php } ?>
			</div>
		</div>
		<!-- End of Owl Carousel -->
	</div>

	<div class="main-2 container">
		<div class="row" style="border-bottom: 1px solid #eee; margin-bottom: 10px;">
			<div class="col-9">
				<h4>About Us</h4>
				<img style="float: left; width: 100px; margin: 8px 20px 0px 0px;" src="<?php echo base_url() ?>img/logo/logo2.png">
				<p>Green House menyediakan layanan jual beli produk pertanian dan perkebunan. Produk yang dijual di Green House diambil langsung dari pertanian terbaik yang ada di daerah Bandung dan sekitarnya yang kualitasnya tidak perlu diragukan lagi. Green House dikelola oleh 4 admin yang sangat professional, yaitu Aditya, Hafiz, Raihan, dan Restu.</p>
			</div>
			<div class="col-3">
				<h4>Customer Service</h4>
				<ul>
					<li><a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLScchYk9dq9CBoBy21_uwqhx5vOhKq-As8MAmQxslNMoDrof3w/viewform">Kritik dan Saran</a></li>
					<li><a href="<?php echo base_url()?>page/about">Tentang Kami</a></li>
					<li><a href="<?php echo base_url()?>page/signup">Sign Up</a></li>
					<li><a href="<?php echo base_url()?>page/signin">Sign In</a></li>
				</ul>
			</div>
		</div>
		<div class="row" style="margin-top: 20px;">
			<!-- Sosial Media -->
			<div class="col">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/facebook.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/twitter.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/instagram.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/youtube.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/googleplus.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/pinterest.png">
			</div>
			<!-- End of Sosial Media -->
			<div class="col">
				<div class="input-group mb-3" style="margin-top: 12px;">
				  	<input type="text" class="form-control" placeholder="Enter your email address.." aria-label="Recipient's username" aria-describedby="basic-addon2">
				  	<div class="input-group-append">
				    	<button class="btn btn-outline-secondary" type="button">Subscribe</button>
				  	</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<div class="footer">
		<div class="mx-auto d-table">
			<span style="font-size: 11px;">
				Copyright 2018 - All Right reserved - Made with&nbsp;&nbsp;<span class="fa fa-heart" style="color:white;"></span>
			</span>
		</div>
	</div>
	<!-- End of Footer -->

	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>js/owl.carousel.js"></script>
	<script>
	$(document).ready(function() {
		$('.owl-carousel').owlCarousel({
		    loop:true,
		    margin:20,
		    nav:true,
		    multipleRow:true,
		    rows:2,
		    responsive:{
		        0:{
		            items:1
		        },
		        600:{
		            items:3
		        },
		        1000:{
		            items:4
		        }
		    }
		})
	})
	</script>
</body>
</html>