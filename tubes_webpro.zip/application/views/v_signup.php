<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?> | Green House</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/fontawesome-all.css">
	<link rel="shortcut icon" href="<?php echo base_url() ?>img/favicon/icon.ico"/>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet"> 
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<div class="top-nav container">
			<ul>
			  	<li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span>&nbsp;&nbsp;Home</a></li>
			  	<li><a href="<?php echo base_url() ?>page/about"><span class="fa fa-address-card"></span>&nbsp;&nbsp;About Us</a></li>
			  	<li><a href="<?php echo base_url() ?>page/admin"><span class="fa fa-user-secret"></span>&nbsp;&nbsp;Admin</a></li>
			  	<?php if (!$this->session->has_userdata('name')) { ?>
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>page/signin"><span class="fa fa-sign-in-alt"></span>&nbsp;&nbsp;Sign In</a></li>
					<li class="active2 res" style="float:right"><a href="<?php echo base_url() ?>page/signup"><span class="fa fa-user-plus"></span>&nbsp;&nbsp;Sign Up</a></li>
				<?php } else { ?>				
					<li class="res" style="float:right"><a href="<?php echo base_url() ?>logout"><span class="fa fa-sign-out-alt"></span>&nbsp;&nbsp;Sign Out</a></li>
					<li class="res" style="float:right">
						<a href="<?php echo base_url() ?>page/cart">
							<span class="fa fa-shopping-cart"></span>&nbsp;&nbsp;Cart
							<?php if (isset($cart_quantity)) { ?>
							&nbsp;&nbsp;<span class="badge badge-danger"><?php echo $cart_quantity ?></span>
							<?php } ?>
						</a>
					</li>
					<li class="res" style="float:right; margin:10px 30px 0px 0px;"><span style="color: white;">Halo, <?php echo $this->session->userdata('name') ?> :)</span></li>
				<?php }	?>
			</ul>
		</div>
	</nav>
	<div class="container">
		<div class="row header">
			<div class="col">
				<img style="width: 480px;" src="<?php echo base_url() ?>img/logo/logo.png">
			</div>
			<div class="col">
				<!-- Search -->
				<form method="post" action="<?php echo base_url()?>page/search">
					<div class="input-group mb-3" style="margin-top: 60px;">
					  	<input name="search" type="text" class="form-control" placeholder="Search here..." required>
					  	<div class="input-group-append">
					    	<input type="submit" class="btn btn-outline-secondary" type="button" value="Search">
					  	</div>
					</div>
				</form>				
				<!-- End of Search -->
			</div>
		</div>
	</div>

	<div class="main container">
		<!-- Pendaftaran Anggota -->
		<form method="post" action="<?php echo base_url() ?>signup">
			<h2>Daftar</h2>
			<div class="form-group">
			   	<label for="inputAddress">Nama</label>
			   	<input name="name" type="text" class="form-control name" id="inputName" placeholder="Aditya Eka Bagaskara" required>
			</div>
			<div class="form-row">
			   	<div class="form-group col-md-6">
			   		<label for="inputEmail4">Username</label>
			   		<input name="username" type="text" class="form-control username" id="inputEmail" placeholder="adityaeka26" required>
			   	</div>
				<div class="form-group col-md-6">
			   		<label for="inputPassword4">Password</label>
			   		<input name="password" type="password" class="form-control password" id="inputPassword" placeholder="123456789" required>
			  	</div>
			</div>
			<div class="form-group">
			   	<label for="inputAddress">Email</label>
			   	<input name="email" type="email" class="form-control username" id="inputEmail" placeholder="aditya@bagas31.com" required>
			</div>
			<div class="form-group">
			  	<label for="inputAddress">Umur</label>
			   	<input name="age" type="text" class="form-control umur" id="inputAge" placeholder="19" required>
			</div>
			<div class="form-group">
			   	<label for="inputAddress">Nomor Telepon</label>
			   	<input name="phone" type="text" class="form-control notelp" id="inputPhone" placeholder="081357687939" required>
			</div>
			<input style="margin-top: 10px;" type="submit" class="btn btn-primary" value="Daftar">
		</form>
		<!-- End of Pendaftaran Anggota -->
	</div>

	<div class="main-2 container">
		<div class="row" style="border-bottom: 1px solid #eee; margin-bottom: 10px;">
			<div class="col-9">
				<h4>About Us</h4>
				<img style="float: left; width: 100px; margin: 8px 20px 0px 0px;" src="<?php echo base_url() ?>img/logo/logo2.png">
				<p>Green House menyediakan layanan jual beli produk pertanian dan perkebunan. Produk yang dijual di Green House diambil langsung dari pertanian terbaik yang ada di daerah Bandung dan sekitarnya yang kualitasnya tidak perlu diragukan lagi. Green House dikelola oleh 4 admin yang sangat professional, yaitu Aditya, Hafiz, Raihan, dan Restu.</p>
			</div>
			<div class="col-3">
				<h4>Customer Service</h4>
				<ul>
					<li><a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLScchYk9dq9CBoBy21_uwqhx5vOhKq-As8MAmQxslNMoDrof3w/viewform">Kritik dan Saran</a></li>
					<li><a href="<?php echo base_url()?>page/about">Tentang Kami</a></li>
					<li><a href="<?php echo base_url()?>page/signup">Sign Up</a></li>
					<li><a href="<?php echo base_url()?>page/signin">Sign In</a></li>
				</ul>
			</div>
		</div>
		<div class="row" style="margin-top: 20px;">
			<div class="col">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/facebook.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/twitter.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/instagram.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/youtube.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/googleplus.png">
				<img class="sosmed" src="<?php echo base_url() ?>img/icon/pinterest.png">
			</div>
			<div class="col">
				<div class="input-group mb-3" style="margin-top: 12px;">
				  	<input type="text" class="form-control" placeholder="Enter your email address.." aria-label="Recipient's username" aria-describedby="basic-addon2">
				  	<div class="input-group-append">
				    	<button class="btn btn-outline-secondary" type="button">Subscribe</button>
				  	</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer">
		<div class="mx-auto d-table">
			<span style="font-size: 11px;">
				Copyright 2018 - All Right reserved - Made with&nbsp;&nbsp;<span class="fa fa-heart" style="color:white;"></span>
			</span>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url() ?>js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>js/bootstrap.js"></script>
</body>
</html>